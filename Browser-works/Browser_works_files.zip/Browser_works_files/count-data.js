var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0","multiple":"{num}","one":"1"}},"counts":[{"id":"http:\/\/www.html5rocks.com\/tutorials\/internals\/howbrowserswork\/","comments":139}]});
}